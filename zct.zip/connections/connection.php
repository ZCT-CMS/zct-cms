<?php

try{
  $pdo = new PDO('mysql:host=sql17.dnsserver.eu; dbname=db90687xweb11', 'db90687xweb11', '70:ci?Nw6ABjt');
} catch(PDOException $e){
  exit('Database error.');
}

?>