  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700,900" rel="stylesheet">
  <script src="https://kit.fontawesome.com/8d6b8d0e75.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="/fonts/icomoon/style.css">
  
  <link rel="stylesheet" href="/css/lightbox.min.css">
  <link rel="stylesheet" href="/css/bootstrap.min.css">
  <link rel="stylesheet" href="/css/aos.css">

  <link rel="stylesheet" href="/css/style.css?v2.2">
  

  <!-- <link href="/images/favicon.png?v4" rel="icon" type="image/png"> -->