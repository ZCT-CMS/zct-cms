    <footer class="footer-section bg-dark">
      <div class="container">
        <div class="row justify-content-between">

          <div class="footer-col col-12">
            <h3 class="text-white">ABOUT US</h3>
            <p class="text-white text-justify">SCALEUP. brings digital transformation and solutions to fast-growing companies as well as family businesses. We do scale-up advisory and can help to accelerate your growth in the areas of Market Research, Sales, HR, Data Analytics, Productivity and Automation. We are an international team, fluent in 10+ languages, specialists in more than 100 cloud-based tools, with strong local knowledge and presence. Let’s scale-up together!</p>
          </div>
        </div>
      </div>
      
    </footer>